void to_binary(unsigned long n);
int count_bit(unsigned long number);
