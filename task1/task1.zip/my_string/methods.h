int my_strcmp(const char *s1, const char *s2);
int my_strchr(const char *str, const int n);
int my_strncmp(const char *s1, const char *s2, const int n);