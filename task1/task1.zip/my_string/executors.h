void execute_my_strcmp();
void execute_my_strncmp();
void execute_my_strchr();